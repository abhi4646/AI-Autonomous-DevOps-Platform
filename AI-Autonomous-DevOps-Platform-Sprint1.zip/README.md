# AI Autonomous DevOps & SDLC Platform

## Overview

AI Autonomous DevOps & SDLC Platform is a staged portfolio project focused on building an AI-powered multi-agent platform for DevOps, SRE, Platform Engineering, and software delivery automation.

The long-term goal is to automate the software delivery lifecycle from Jira ticket intake to GitHub pull requests, CI/CD validation, infrastructure automation, Kubernetes deployment, monitoring, and documentation, while keeping humans in control through approval gates.

## Sprint 1 Scope

This first sprint creates the clean engineering foundation:

- FastAPI backend
- Health check API
- Configuration management
- Logging
- Docker support
- Docker Compose
- GitHub Actions CI
- Basic tests
- Architecture documentation

## Current Status

Sprint 1 foundation is complete.

## Planned Roadmap

### Sprint 1 — Foundation
- Repository structure
- FastAPI app
- Docker support
- CI pipeline
- Health check test

### Sprint 2 — AI Orchestrator
- Ticket analysis model
- Agent router
- Local LLM / OpenAI integration
- LangGraph workflow skeleton

### Sprint 3 — Jira and GitHub Agents
- Jira ticket intake
- GitHub branch and PR automation

### Sprint 4 — DevOps Agents
- Terraform Agent
- Kubernetes Agent
- Docker Agent
- CI/CD Agent

### Sprint 5 — Security, Monitoring, Documentation
- Security scanning
- Deployment validation
- Release notes
- Observability checks

## Tech Stack

- Python
- FastAPI
- Pydantic
- Docker
- GitHub Actions
- Pytest
- Future: LangGraph, MCP, OpenAI/Ollama, Jira API, GitHub API, Terraform, Kubernetes

## Run Locally

```bash
pip install -r requirements.txt
uvicorn src.main:app --reload
```

Open:

```text
http://127.0.0.1:8000/health
```

## Run with Docker

```bash
docker compose up --build
```

## Author

Naga Abhishek Derangula  
Senior DevOps Engineer | SRE | Platform Engineer
