from fastapi import APIRouter

from src.core.config import settings

router = APIRouter()


@router.get("/")
def root() -> dict:
    return {
        "service": settings.app_name,
        "status": "running",
        "version": "0.1.0",
    }


@router.get("/health")
def health_check() -> dict:
    return {
        "status": "healthy",
        "environment": settings.app_env,
    }
